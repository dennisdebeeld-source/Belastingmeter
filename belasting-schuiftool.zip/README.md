# Belasting schuiftool (static)
Een single-file webapp. Open `index.html` lokaal of host als static site.

## Lokaal (mobiel of desktop)
- Open `index.html` in je browser. Werkt offline.

## Vercel
1. Maak een nieuw project "Other" (Static).
2. Upload `index.html` in de root.
3. Deploy. Klaar.

## GitHub Pages
1. Nieuwe repo, commit `index.html` in de root.
2. Settings → Pages → Deploy from branch → `main` / root.
3. Wacht tot de site live is.
